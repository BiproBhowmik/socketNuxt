<template>
    <div>
        <div class="_1main_content">
            <div class="_advertise_layout">
                <!-- <div class="_mar_b20">
                    <Alert show-icon>
                        <strong>Info:</strong>You can use the following PayPal account for upgrading:
                        <template slot="desc">
                            Email: sb-hysua1133883@personal.example.com<br/>
                            Password: 123456789
                        </template>
                    </Alert>
                </div> -->

                <div class="_advertise_row">
                    <!-- Left section -->
                    <div class="_advertise_left">
                        <div class="_advertise_left_card _mar_b20">
                            <div class="_advertise_left_card_top">
                                <p class="_advertise_left_card_title">Current Balance</p>
                                <p class="_advertise_left_card_amm">$106.70</p>
                            </div>

                            <ul class="_advertise_left_list">
                                <li>
                                    <router-link to="/advertise">
                                        <i class="fas fa-bullhorn"></i> Campaigns
                                    </router-link>
                                </li>
                                <li>
                                    <router-link to="/advertiseWallet">
                                        <i class="fas fa-wallet"></i> Wallet
                                    </router-link>
                                </li>
                                <li class="_active">
                                    <router-link to="/advertisingPolicies">
                                        <i class="fas fa-newspaper"></i> Advertising Policies
                                    </router-link>
                                </li>
                                <li class="_advertise_new">
                                    <router-link to="/advertiseNewCampaign">
                                        <i class="fas fa-plus-circle"></i> New Campaign
                                    </router-link>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- Left section -->

                    <!-- Right section -->
                    <div class="_advertise_right">
                        <div class="_advertise_card _mar_b20">
                            <h2 class="_advertise_title _1title"><i class="fas fa-newspaper"></i> Advertising Policies</h2>

                            <div class="_advertise_des">
                                <p class="_advertise_Sub_title _3title">Role No 1</p>
                                
                                <p class="_advertise_text">Sellus aliquam portamor leocras itor aliquam roin. Himena tempor habitant eratetia uada felis. Necmae nec nisiinte non facilisi ivamus. Liberom unc cras lus tortorp mauris orciut vamus onec faucibus.</p>
                            </div>
                            <div class="_advertise_des">
                                <p class="_advertise_Sub_title _3title">Role No 2</p>
                                
                                <p class="_advertise_text">Sellus aliquam portamor leocras itor aliquam roin. Himena tempor habitant eratetia uada felis. Necmae nec nisiinte non facilisi ivamus. Liberom unc cras lus tortorp mauris orciut vamus onec faucibus.</p>
                            </div>
                            <div class="_advertise_des">
                                <p class="_advertise_Sub_title _3title">Role No 3</p>
                                
                                <p class="_advertise_text">Sellus aliquam portamor leocras itor aliquam roin. Himena tempor habitant eratetia uada felis. Necmae nec nisiinte non facilisi ivamus. Liberom unc cras lus tortorp mauris orciut vamus onec faucibus.</p>
                            </div>
                            <div class="_advertise_des">
                                <p class="_advertise_Sub_title _3title">Role No 4</p>
                                
                                <p class="_advertise_text">Sellus aliquam portamor leocras itor aliquam roin. Himena tempor habitant eratetia uada felis. Necmae nec nisiinte non facilisi ivamus. Liberom unc cras lus tortorp mauris orciut vamus onec faucibus.</p>
                            </div>
                            <div class="_advertise_des">
                                <p class="_advertise_Sub_title _3title">Role No 5</p>
                                
                                <p class="_advertise_text">Sellus aliquam portamor leocras itor aliquam roin. Himena tempor habitant eratetia uada felis. Necmae nec nisiinte non facilisi ivamus. Liberom unc cras lus tortorp mauris orciut vamus onec faucibus.Sellus aliquam portamor leocras itor aliquam roin. Himena tempor habitant eratetia uada felis. Necmae nec nisiinte non facilisi ivamus. Liberom unc cras lus tortorp mauris orciut vamus onec faucibus.</p>
                            </div>
                        </div>
                    </div>
                    <!-- Right section -->
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
  components: {
      
  },

  data(){
    return{
      
    }
  },

  methods:{
    
  },
  
  created(){
    
  }
}
</script>