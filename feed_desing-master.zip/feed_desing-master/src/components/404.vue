<template>
    <div>
        <div class="_1main_content">
            <div class="_404page_layout">
                <div class="_404page_card">
                    <h2 class="_1title _404page_title">This page does not exist</h2>
                    <p class="_404page_text">
                        The link that you're trying to access may be incorrect or the page was removed.<br/>
                        Please check the link again and see if it's correct.
                    </p>

                    <div class="_404page_button">
                        <router-link to="/"><button class="_2btn" type="button">Go to Newsfeed</button></router-link>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>