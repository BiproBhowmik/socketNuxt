<template>
    <div>
        <div class="_2menu">
            <div class="_2menu_con">
                <div class="row align-items-center">
                    <div class="col">
                        <router-link to="/">
                            <h3 class="_menu_logo_text">
                                <span class="_menu_logo_symbol">C</span>
                                <span class="_menu_logo_text_main">CONNECTIVER</span>
                            </h3>
                        </router-link>
                    </div>

                    <div class="col-auto">
                        <router-link to="/signUp">
                            <button class="_log_btn _2menu_long" type="button">Sign Up</button>
                        </router-link>
                    </div>
                </div>
            </div>
        </div>

        <!-- Banner -->
        <div class="_4banner">
            <div class="_4banner_main">
                <h1 class="_4banner_title">Privacy</h1>
                <p class="_4banner_text">Find out everything you need to know Privacy Connectiver</p>
            </div>
        </div>
        <!-- Banner -->

        <!-- Content -->
        <div class="_support_layout">
            <div class="_support_card">
                <div class="_support_card_items">
                    <h2 class="_support_title">Why did we create Connectiver?</h2>
                    <p class="_support_text">
                        Lorem ipsum dolor sit amet, his fabulas persequeris te, everti legendos dissentiunt cu est, id vix 
                        laoreet vivendo. In vis esse temporibus, stet dicat cum eu. Id duo equidem legimus. Eum dolore 
                        intellegat in, wisi nulla paulo an nec.
                    </p>

                    <p class="_support_text">Facer choro appetere id mel, ut his dictas senserit quaerendum. Te eum ullum temporibus, eu sea ignota tibique epicurei. Stet probo quaestio his no, ex eam iriure iudicabit theophrastus. Vim eu mundi dicant libris, vix et dolorem facilis omittantur, eam ullum viderer ad. Ea repudiandae efficiantur nec. Ei enim recteque consequuntur cum, eos an elitr placerat sadipscing. No elit autem elaboraret duo.</p>
                    <p class="_support_text">Eum perfecto percipitur persequeris ea, cum id suas aliquid neglegentur. Ius ex habeo persius delicata, legimus appetere eos ei. Dicam phaedrum nam at, alia option saperet cu mei, has in case nusquam. Mollis luptatum ius et, ex euismod voluptaria mel. Probo iuvaret legimus ad pro, pro autem justo partem et.</p>
                </div>

                <div class="_support_card_items">
                    <h1 class="_support_title">What exactly is this platform?</h1>
                    <p class="_support_text">
                        Lorem ipsum dolor sit amet, his fabulas persequeris te, everti legendos dissentiunt cu est, id vix 
                        laoreet vivendo. In vis esse temporibus, stet dicat cum eu. Id duo equidem legimus. Eum dolore 
                        intellegat in, wisi nulla paulo an nec.
                    </p>

                    <p class="_support_text">Facer choro appetere id mel, ut his dictas senserit quaerendum. Te eum ullum temporibus, eu sea ignota tibique epicurei. Stet probo quaestio his no, ex eam iriure iudicabit theophrastus. Vim eu mundi dicant libris, vix et dolorem facilis omittantur, eam ullum viderer ad. Ea repudiandae efficiantur nec. Ei enim recteque consequuntur cum, eos an elitr placerat sadipscing. No elit autem elaboraret duo.</p>
                    <p class="_support_text">Eum perfecto percipitur persequeris ea, cum id suas aliquid neglegentur. Ius ex habeo persius delicata, legimus appetere eos ei. Dicam phaedrum nam at, alia option saperet cu mei, has in case nusquam. Mollis luptatum ius et, ex euismod voluptaria mel. Probo iuvaret legimus ad pro, pro autem justo partem et.</p>
                </div>

                <div class="_support_card_items">
                    <h1 class="_support_title">Who created this platform?</h1>
                    <p class="_support_text">
                        Lorem ipsum dolor sit amet, his fabulas persequeris te, everti legendos dissentiunt cu est, id vix 
                        laoreet vivendo. In vis esse temporibus, stet dicat cum eu. Id duo equidem legimus. Eum dolore 
                        intellegat in, wisi nulla paulo an nec.
                    </p>

                    <p class="_support_text">Facer choro appetere id mel, ut his dictas senserit quaerendum. Te eum ullum temporibus, eu sea ignota tibique epicurei. Stet probo quaestio his no, ex eam iriure iudicabit theophrastus. Vim eu mundi dicant libris, vix et dolorem facilis omittantur, eam ullum viderer ad. Ea repudiandae efficiantur nec. Ei enim recteque consequuntur cum, eos an elitr placerat sadipscing. No elit autem elaboraret duo.</p>
                    <p class="_support_text">Eum perfecto percipitur persequeris ea, cum id suas aliquid neglegentur. Ius ex habeo persius delicata, legimus appetere eos ei. Dicam phaedrum nam at, alia option saperet cu mei, has in case nusquam. Mollis luptatum ius et, ex euismod voluptaria mel. Probo iuvaret legimus ad pro, pro autem justo partem et.</p>
                </div>

                <div class="_support_card_items">
                    <h1 class="_support_title">What do we do to provide you with a great experience?</h1>
                    <p class="_support_text">
                        Lorem ipsum dolor sit amet, his fabulas persequeris te, everti legendos dissentiunt cu est, id vix 
                        laoreet vivendo. In vis esse temporibus, stet dicat cum eu. Id duo equidem legimus. Eum dolore 
                        intellegat in, wisi nulla paulo an nec.
                    </p>

                    <p class="_support_text">Facer choro appetere id mel, ut his dictas senserit quaerendum. Te eum ullum temporibus, eu sea ignota tibique epicurei. Stet probo quaestio his no, ex eam iriure iudicabit theophrastus. Vim eu mundi dicant libris, vix et dolorem facilis omittantur, eam ullum viderer ad. Ea repudiandae efficiantur nec. Ei enim recteque consequuntur cum, eos an elitr placerat sadipscing. No elit autem elaboraret duo.</p>
                    <p class="_support_text">Eum perfecto percipitur persequeris ea, cum id suas aliquid neglegentur. Ius ex habeo persius delicata, legimus appetere eos ei. Dicam phaedrum nam at, alia option saperet cu mei, has in case nusquam. Mollis luptatum ius et, ex euismod voluptaria mel. Probo iuvaret legimus ad pro, pro autem justo partem et.</p>
                </div>

                <div class="_support_card_items">
                    <h1 class="_support_title">How is the platform funding itself?</h1>
                    <p class="_support_text">
                        Lorem ipsum dolor sit amet, his fabulas persequeris te, everti legendos dissentiunt cu est, id vix 
                        laoreet vivendo. In vis esse temporibus, stet dicat cum eu. Id duo equidem legimus. Eum dolore 
                        intellegat in, wisi nulla paulo an nec.
                    </p>

                    <p class="_support_text">Facer choro appetere id mel, ut his dictas senserit quaerendum. Te eum ullum temporibus, eu sea ignota tibique epicurei. Stet probo quaestio his no, ex eam iriure iudicabit theophrastus. Vim eu mundi dicant libris, vix et dolorem facilis omittantur, eam ullum viderer ad. Ea repudiandae efficiantur nec. Ei enim recteque consequuntur cum, eos an elitr placerat sadipscing. No elit autem elaboraret duo.</p>
                    <p class="_support_text">Eum perfecto percipitur persequeris ea, cum id suas aliquid neglegentur. Ius ex habeo persius delicata, legimus appetere eos ei. Dicam phaedrum nam at, alia option saperet cu mei, has in case nusquam. Mollis luptatum ius et, ex euismod voluptaria mel. Probo iuvaret legimus ad pro, pro autem justo partem et.</p>
                </div>

                <div class="_support_card_items">
                    <h1 class="_support_title">What do we do to respect your data and privacy?</h1>
                    <p class="_support_text">
                        Lorem ipsum dolor sit amet, his fabulas persequeris te, everti legendos dissentiunt cu est, id vix 
                        laoreet vivendo. In vis esse temporibus, stet dicat cum eu. Id duo equidem legimus. Eum dolore 
                        intellegat in, wisi nulla paulo an nec.
                    </p>

                    <p class="_support_text">Facer choro appetere id mel, ut his dictas senserit quaerendum. Te eum ullum temporibus, eu sea ignota tibique epicurei. Stet probo quaestio his no, ex eam iriure iudicabit theophrastus. Vim eu mundi dicant libris, vix et dolorem facilis omittantur, eam ullum viderer ad. Ea repudiandae efficiantur nec. Ei enim recteque consequuntur cum, eos an elitr placerat sadipscing. No elit autem elaboraret duo.</p>
                    <p class="_support_text">Eum perfecto percipitur persequeris ea, cum id suas aliquid neglegentur. Ius ex habeo persius delicata, legimus appetere eos ei. Dicam phaedrum nam at, alia option saperet cu mei, has in case nusquam. Mollis luptatum ius et, ex euismod voluptaria mel. Probo iuvaret legimus ad pro, pro autem justo partem et.</p>
                </div>

                <div class="_support_card_items">
                    <h1 class="_support_title">What are our content moderation practices?</h1>
                    <p class="_support_text">
                        Lorem ipsum dolor sit amet, his fabulas persequeris te, everti legendos dissentiunt cu est, id vix 
                        laoreet vivendo. In vis esse temporibus, stet dicat cum eu. Id duo equidem legimus. Eum dolore 
                        intellegat in, wisi nulla paulo an nec.
                    </p>

                    <p class="_support_text">Facer choro appetere id mel, ut his dictas senserit quaerendum. Te eum ullum temporibus, eu sea ignota tibique epicurei. Stet probo quaestio his no, ex eam iriure iudicabit theophrastus. Vim eu mundi dicant libris, vix et dolorem facilis omittantur, eam ullum viderer ad. Ea repudiandae efficiantur nec. Ei enim recteque consequuntur cum, eos an elitr placerat sadipscing. No elit autem elaboraret duo.</p>
                    <p class="_support_text">Eum perfecto percipitur persequeris ea, cum id suas aliquid neglegentur. Ius ex habeo persius delicata, legimus appetere eos ei. Dicam phaedrum nam at, alia option saperet cu mei, has in case nusquam. Mollis luptatum ius et, ex euismod voluptaria mel. Probo iuvaret legimus ad pro, pro autem justo partem et.</p>
                </div>

                <div class="_support_card_items">
                    <h1 class="_support_title">How does the newsfeed work?</h1>
                    <p class="_support_text">
                        Lorem ipsum dolor sit amet, his fabulas persequeris te, everti legendos dissentiunt cu est, id vix 
                        laoreet vivendo. In vis esse temporibus, stet dicat cum eu. Id duo equidem legimus. Eum dolore 
                        intellegat in, wisi nulla paulo an nec.
                    </p>

                    <p class="_support_text">Facer choro appetere id mel, ut his dictas senserit quaerendum. Te eum ullum temporibus, eu sea ignota tibique epicurei. Stet probo quaestio his no, ex eam iriure iudicabit theophrastus. Vim eu mundi dicant libris, vix et dolorem facilis omittantur, eam ullum viderer ad. Ea repudiandae efficiantur nec. Ei enim recteque consequuntur cum, eos an elitr placerat sadipscing. No elit autem elaboraret duo.</p>
                    <p class="_support_text">Eum perfecto percipitur persequeris ea, cum id suas aliquid neglegentur. Ius ex habeo persius delicata, legimus appetere eos ei. Dicam phaedrum nam at, alia option saperet cu mei, has in case nusquam. Mollis luptatum ius et, ex euismod voluptaria mel. Probo iuvaret legimus ad pro, pro autem justo partem et.</p>
                </div>

                <div class="_support_card_items">
                    <h1 class="_support_title">Can people rely on this platform?</h1>
                    <p class="_support_text">
                        Lorem ipsum dolor sit amet, his fabulas persequeris te, everti legendos dissentiunt cu est, id vix 
                        laoreet vivendo. In vis esse temporibus, stet dicat cum eu. Id duo equidem legimus. Eum dolore 
                        intellegat in, wisi nulla paulo an nec.
                    </p>

                    <p class="_support_text">Facer choro appetere id mel, ut his dictas senserit quaerendum. Te eum ullum temporibus, eu sea ignota tibique epicurei. Stet probo quaestio his no, ex eam iriure iudicabit theophrastus. Vim eu mundi dicant libris, vix et dolorem facilis omittantur, eam ullum viderer ad. Ea repudiandae efficiantur nec. Ei enim recteque consequuntur cum, eos an elitr placerat sadipscing. No elit autem elaboraret duo.</p>
                    <p class="_support_text">Eum perfecto percipitur persequeris ea, cum id suas aliquid neglegentur. Ius ex habeo persius delicata, legimus appetere eos ei. Dicam phaedrum nam at, alia option saperet cu mei, has in case nusquam. Mollis luptatum ius et, ex euismod voluptaria mel. Probo iuvaret legimus ad pro, pro autem justo partem et.</p>
                </div>

                <div class="_support_card_items">
                    <h1 class="_support_title">What is the future vision for Connectiver?</h1>
                    <p class="_support_text">
                        Lorem ipsum dolor sit amet, his fabulas persequeris te, everti legendos dissentiunt cu est, id vix 
                        laoreet vivendo. In vis esse temporibus, stet dicat cum eu. Id duo equidem legimus. Eum dolore 
                        intellegat in, wisi nulla paulo an nec.
                    </p>

                    <p class="_support_text">Facer choro appetere id mel, ut his dictas senserit quaerendum. Te eum ullum temporibus, eu sea ignota tibique epicurei. Stet probo quaestio his no, ex eam iriure iudicabit theophrastus. Vim eu mundi dicant libris, vix et dolorem facilis omittantur, eam ullum viderer ad. Ea repudiandae efficiantur nec. Ei enim recteque consequuntur cum, eos an elitr placerat sadipscing. No elit autem elaboraret duo.</p>
                    <p class="_support_text">Eum perfecto percipitur persequeris ea, cum id suas aliquid neglegentur. Ius ex habeo persius delicata, legimus appetere eos ei. Dicam phaedrum nam at, alia option saperet cu mei, has in case nusquam. Mollis luptatum ius et, ex euismod voluptaria mel. Probo iuvaret legimus ad pro, pro autem justo partem et.</p>
                </div>
            </div>
        </div>
        <!-- Content -->
    </div>
</template>